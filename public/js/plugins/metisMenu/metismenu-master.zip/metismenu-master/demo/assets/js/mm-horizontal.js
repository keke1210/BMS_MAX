$(function() {

  $('#menu1').metisMenu();

  $('#menu2').metisMenu();

});
